import tkinter as tk
from tkinter import messagebox
import random


# Fungsi untuk menghasilkan pilihan komputer
def komputer_pilih():
  pilihan = ["Gunting", "Batu", "Kertas"]
  return random.choice(pilihan)


# Fungsi untuk mengecek pemenang
def cek_pemenang(pilihan_pengguna, pilihan_komputer):
  if pilihan_pengguna == pilihan_komputer:
    return "SERI"
  elif (pilihan_pengguna == "Gunting" and pilihan_komputer == "Kertas") or \
       (pilihan_pengguna == "Batu" and pilihan_komputer == "Gunting") or \
       (pilihan_pengguna == "Kertas" and pilihan_komputer == "Batu"):
    return "Anda MENANG!"
  else:
    return "Anda KALAH!"


# Fungsi saat tombol "Main" diklik
def main():
  pilihan_pengguna = pengguna.get()

  if pilihan_pengguna not in ["Gunting", "Batu", "Kertas"]:
    messagebox.showerror("Kesalahan", "Pilihan tidak valid!")
    return

  pilihan_komputer = komputer_pilih()
  hasil = cek_pemenang(pilihan_pengguna, pilihan_komputer)

  messagebox.showinfo(
    "Hasil",
    f"Anda memilih: {pilihan_pengguna}\nKomputer memilih: {pilihan_komputer}\n\n{hasil}"
  )


# Membuat jendela GUI
root = tk.Tk()
root.title("Game Gunting Batu Kertas")

# Membuat label
label = tk.Label(root, text="Pilih: Gunting, Batu, Kertas")
label.pack()

# Membuat input pengguna
pengguna = tk.StringVar()
entry = tk.Entry(root, textvariable=pengguna)
entry.pack()

# Membuat tombol "Main"
button = tk.Button(root, text="Mulai", command=main)
button.pack()

root.mainloop()
